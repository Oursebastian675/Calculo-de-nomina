package com.example.application.views.calculadora;

import com.example.application.views.MainLayout;
import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dependency.Uses;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;

@PageTitle("Calculadora")
@Route(value = "my-view2", layout = MainLayout.class)
@Uses(Icon.class)
public class CalculadoraView extends Composite<VerticalLayout> {

    public CalculadoraView() {
        H1 h1 = new H1();
        TextField textField = new TextField();
        NumberField numberField = new NumberField();
        NumberField numberField2 = new NumberField();
        NumberField numberField3 = new NumberField();
        Button buttonSecondary = new Button();
        getContent().setWidth("100%");
        getContent().getStyle().set("flex-grow", "1");
        h1.setText("Calculadora");
        getContent().setAlignSelf(FlexComponent.Alignment.CENTER, h1);
        h1.setWidth("max-content");
        textField.setLabel("Nombre del empleado");
        getContent().setAlignSelf(FlexComponent.Alignment.CENTER, textField);
        textField.setWidth("400px");
        numberField.setLabel("Horas trabajadas");
        getContent().setAlignSelf(FlexComponent.Alignment.CENTER, numberField);
        numberField.setWidth("400px");
        numberField2.setLabel("Tarifa por horas");
        getContent().setAlignSelf(FlexComponent.Alignment.CENTER, numberField2);
        numberField2.setWidth("400px");
        numberField3.setLabel("Tipo de contrato (Fijo o por horas)");
        getContent().setAlignSelf(FlexComponent.Alignment.CENTER, numberField3);
        numberField3.setWidth("400px");
        buttonSecondary.setText("Calcular");
        getContent().setAlignSelf(FlexComponent.Alignment.CENTER, buttonSecondary);
        buttonSecondary.setWidth("230px");
        getContent().add(h1);
        getContent().add(textField);
        getContent().add(numberField);
        getContent().add(numberField2);
        getContent().add(numberField3);
        getContent().add(buttonSecondary);
    }
}
